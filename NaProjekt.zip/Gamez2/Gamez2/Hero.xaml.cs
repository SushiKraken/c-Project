﻿using System.Windows.Controls;

namespace Gamez2
{
    /// <summary>
    /// Interaction logic for Hero.xaml
    /// </summary>
    public partial class Hero : UserControl
    {
        public Hero()
        {
            InitializeComponent();
        }
    }
}
