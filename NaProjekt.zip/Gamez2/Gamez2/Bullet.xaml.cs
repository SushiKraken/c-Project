﻿using System.Windows.Controls;

namespace Gamez2
{
    /// <summary>
    /// Interaction logic for Bullet.xaml
    /// </summary>
    public partial class Bullet : UserControl
    {
       
        public Bullet
       ()
        {
            InitializeComponent();
            

        }
    }
}
